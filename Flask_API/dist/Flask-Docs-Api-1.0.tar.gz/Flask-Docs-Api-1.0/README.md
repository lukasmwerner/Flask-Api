# Flask-Docs-Api

A library to make doc generation painless

Sample Usage (copy & paste)

```python
from flask_api_docs.api import Api
api = Api(app, "/docs", globals(), "Test" )
```
